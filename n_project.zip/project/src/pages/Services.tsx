import React from 'react';
import { motion } from 'framer-motion';
import { BrainCircuit, Bot, Code, Database, BarChart3, Lightbulb, CheckCircle2 } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import SectionHeading from '../components/SectionHeading';
import Button from '../components/Button';

const Services: React.FC = () => {
  const serviceCategories = [
    {
      title: "AI Solutions",
      description: "Custom AI models and intelligent systems tailored to your business needs.",
      services: [
        {
          icon: <BrainCircuit className="h-8 w-8 text-primary-600" />,
          title: "Custom AI Model Development",
          description: "We design and develop custom AI models tailored to your specific business requirements, from computer vision to natural language processing.",
          features: [
            "Customized model architecture",
            "Training on your domain-specific data",
            "Optimization for performance and accuracy",
            "Deployment and integration support"
          ],
          src:"public/CUSTOM AI SOLUTION.png"
        },
        {
          icon: <Database className="h-8 w-8 text-primary-600" />,
          title: "RAG-based Knowledge Assistants",
          description: "Retrieval-augmented generation systems that leverage your business data to provide accurate, contextual responses.",
          features: [
            "Document processing and knowledge extraction",
            "Semantic search capabilities",
            "Context-aware responses",
            "Integration with existing knowledge bases"
          ],
          src:"public/Rag.webp"
        },
        {
          icon: <Bot className="h-8 w-8 text-primary-600" />,
          title: "AI Chatbots & AI Agents",
          description: "Intelligent conversational agents that enhance customer experience and automate support processes.",
          features: [
            "Natural language understanding",
            "Multi-turn conversation handling",
            "Integration with business systems",
            "Continuous learning and improvement"
          ],
          src:"public/AI Chatbot.png"
        }
      ]
    },
    {
      title: "AI-Integrated Web Development",
      description: "Web solutions powered by AI for enhanced functionality and user experience.",
      services: [
        {
          icon: <Code className="h-8 w-8 text-primary-600" />,
          title: "Smart, AI-driven Websites",
          description: "Websites that leverage AI to deliver personalized experiences, intelligent search, and automated content generation.",
          features: [
            "Personalized user experiences",
            "AI-powered content recommendations",
            "Intelligent search functionality",
            "Automated content generation"
          ],
          src:"public/AI website.webp"
        },
        {
          icon: <Lightbulb className="h-8 w-8 text-primary-600" />,
          title: "API Integrations with AI Backends",
          description: "Seamless integration of AI capabilities into your existing web applications through robust API connections.",
          features: [
            "Custom API development",
            "Integration with leading AI platforms",
            "Real-time data processing",
            "Scalable architecture design"
          ],
          src:"public/api-integration.webp"
          
        }
      ]
    },
    {
      title: "Data Science & Analytics",
      description: "Transform your data into actionable insights and predictive capabilities.",
      services: [
        {
          icon: <BarChart3 className="h-8 w-8 text-primary-600" />,
          title: "Predictive Modeling & Data Insights",
          description: "Advanced analytics and predictive models that help you anticipate trends, customer behavior, and business opportunities.",
          features: [
            "Data preprocessing and feature engineering",
            "Statistical analysis and visualization",
            "Predictive model development",
            "Actionable business insights"
          ],
          src:"public/predictive-analytics.jpg"

        },
        {
          icon: <Database className="h-8 w-8 text-primary-600" />,
          title: "End-to-end ML Pipeline Development",
          description: "Complete machine learning pipelines from data collection to model deployment and monitoring.",
          features: [
            "Automated data collection and processing",
            "Model training and validation",
            "Deployment to production environments",
            "Monitoring and continuous improvement"
          ],
          src:"public/ML-Pipeline.png"
        }
      ]
    }
  ];

  return (
    <PageTransition>
      {/* Hero Section */}
      <section className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Our <span className="text-primary-600 dark:text-primary-400">Services</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
              We offer a comprehensive range of AI and data science services to help businesses 
              leverage the power of artificial intelligence and machine learning.
            </p>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {serviceCategories.map((category, categoryIndex) => (
            <div key={categoryIndex} className="mb-20">
              <SectionHeading 
                title={category.title} 
                subtitle={category.description}
              />
              
              <div className="space-y-12">
                {category.services.map((service, serviceIndex) => (
                  <motion.div 
                    key={serviceIndex}
                    className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    viewport={{ once: true }}
                  >
                    <div className={`${serviceIndex % 2 === 1 ? 'lg:order-2' : ''}`}>
                      <div className="flex items-center space-x-3 mb-4">
                        <div className="p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                          {service.icon}
                        </div>
                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                          {service.title}
                        </h3>
                      </div>
                      
                      <p className="text-gray-600 dark:text-gray-400 mb-6">
                        {service.description}
                      </p>
                      
                      <div className="space-y-3">
                        {service.features.map((feature, featureIndex) => (
                          <div key={featureIndex} className="flex items-start space-x-3">
                            <CheckCircle2 className="h-5 w-5 text-primary-600 dark:text-primary-400 mt-0.5" />
                            <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className={`${serviceIndex % 2 === 1 ? 'lg:order-1' : ''}`}>
                      <div className="bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden shadow-md">
                      <img 
                          src={service.src} 
                          alt={service.title} 
                          className="w-full h-64 object-cover"
                        />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading 
            title="Our Process" 
            subtitle="We follow a structured approach to ensure successful delivery of AI solutions."
            centered
          />
          
          <div className="max-w-4xl mx-auto">
            {[
              {
                number: "01",
                title: "Discovery & Requirements",
                description: "We begin by understanding your business needs, challenges, and objectives to define clear requirements for your AI solution."
              },
              {
                number: "02",
                title: "Solution Design",
                description: "Our team designs a tailored solution architecture, selecting the appropriate AI technologies and approaches to address your specific needs."
              },
              {
                number: "03",
                title: "Development & Training",
                description: "We develop and train AI models using your data, iteratively refining them to achieve optimal performance and accuracy."
              },
              {
                number: "04",
                title: "Integration & Deployment",
                description: "The solution is integrated with your existing systems and deployed to your preferred environment, ensuring seamless operation."
              },
              {
                number: "05",
                title: "Monitoring & Optimization",
                description: "We continuously monitor the performance of your AI solution, making adjustments and improvements to ensure long-term success."
              }
            ].map((step, index) => (
              <motion.div 
                key={index}
                className="relative pl-16 pb-12"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                {index < 4 && (
                  <div className="absolute left-6 top-0 bottom-0 w-px bg-primary-200 dark:bg-primary-800"></div>
                )}
                <div className="absolute left-0 top-0 flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 font-bold">
                  {step.number}
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  {step.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary-600 to-secondary-700 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">
            Ready to Transform Your Business with AI?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            Contact us today to discuss your project and get a free consultation.
          </p>
          <Button 
            to="/contact" size="lg"
          >
            Get a Free Consultation
          </Button>
        </div>
      </section>
    </PageTransition>
  );
};

export default Services;