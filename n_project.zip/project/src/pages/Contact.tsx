// import React, { useState } from 'react';
// import { motion } from 'framer-motion';
// import { Mail, Phone, MapPin, Send, Github, Linkedin } from 'lucide-react';
// import PageTransition from '../components/PageTransition';
// import SectionHeading from '../components/SectionHeading';
// import Button from '../components/Button';

// const Contact: React.FC = () => {
//   const [formData, setFormData] = useState({
//     name: '',
//     email: '',
//     subject: '',
//     message: ''
//   });
  
//   const [formStatus, setFormStatus] = useState<{
//     submitted: boolean;
//     success: boolean;
//     message: string;
//   }>({
//     submitted: false,
//     success: false,
//     message: ''
//   });

//   const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
//     const { name, value } = e.target;
//     setFormData(prev => ({ ...prev, [name]: value }));
//   };

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();
    
//     // Simulate form submission
//     setFormStatus({
//       submitted: true,
//       success: true,
//       message: 'Thank you for your message! We will get back to you soon.'
//     });
    
//     // Reset form after successful submission
//     setFormData({
//       name: '',
//       email: '',
//       subject: '',
//       message: ''
//     });
    
//     // In a real application, you would send the form data to your backend here
//   };

//   return (
//     <PageTransition>
//       {/* Hero Section */}
//       <section className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
//         <div className="container mx-auto px-4 sm:px-6 lg:px-8">
//           <div className="max-w-4xl mx-auto text-center">
//             <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-6">
//               Get in <span className="text-primary-600 dark:text-primary-400">Touch</span>
//             </h1>
//             <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
//               Have a question or want to discuss a project? We'd love to hear from you.
//             </p>
//           </div>
//         </div>
//       </section>

//       {/* Contact Form Section */}
      // <section className="py-16 bg-white dark:bg-gray-900">
      //   <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      //     <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            {/* <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                Contact Information
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-8">
                Feel free to reach out to us with any questions or inquiries. We're here to help and would love to discuss how our AI solutions can benefit your business.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                    <Mail className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">Email</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      <a href="mailto:dipakgaddam102@gmail.com" className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
                        dipakgaddam102@gmail.com
                      </a>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                    <Phone className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">Phone</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      <a href="tel:+919725359219" className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
                        +91 9725359219
                      </a>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">Location</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      Surat, Gujarat, India
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-8">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Follow Us</h3>
                <div className="flex space-x-4">
                  <a 
                    href="https://github.com/Dipak703" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                    aria-label="GitHub"
                  >
                    <Github className="h-5 w-5" />
                  </a>
                  <a 
                    href="https://www.linkedin.com/in/dipak-gaddam?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                    aria-label="LinkedIn"
                  >
                    <Linkedin className="h-5 w-5" />
                  </a>
                </div>
              </div>
            </motion.div> */}
            
      //       Contact Form
      //       <motion.div
      //         initial={{ opacity: 0, x: 20 }}
      //         whileInView={{ opacity: 1, x: 0 }}
      //         transition={{ duration: 0.5 }}
      //         viewport={{ once: true }}
      //       >
      //         <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
      //           Send Us a Message
      //         </h2> 
              
      //            {formStatus.submitted && (
      //           <div className={`p-4 mb-6 rounded-md ${formStatus.success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
      //             {formStatus.message}
      //           </div>
      //         )}
              
          //     <form onSubmit={handleSubmit} className="space-y-6">
          //       <div>
          //         <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          //           Your Name
          //         </label>
          //         <input
          //           type="text"
          //           id="name"
          //           name="name"
          //           value={formData.name}
          //           onChange={handleChange}
          //           required
          //           className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-white"
          //           placeholder="John Doe"
          //         />
          //       </div>
                
          //       <div>
          //         <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          //           Your Email
          //         </label>
          //        <input
          //           type="email"
          //           id="email"
          //           name="email"
          //           value={formData.email}
          //           onChange={handleChange}
          //           required
          //           className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-white"
          //           placeholder="john@example.com"
          //         />
          //       </div>
                
          //       <div>
          //         <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          //           Subject
          //         </label>
          //         <select
          //           id="subject"
          //           name="subject"
          //           value={formData.subject}
          //           onChange={handleChange}
          //           required
          //           className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-white"
          //         >
          //           <option value="">Select a subject</option>
          //           <option value="General Inquiry">General Inquiry</option>
          //           <option value="Project Discussion">Project Discussion</option>
          //           <option value="Partnership Opportunity">Partnership Opportunity</option>
          //           <option value="Job Application">Job Application</option>
          //           <option value="Other">Other</option>
          //         </select>
          //       </div>
                
          //       <div>
          //         <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          //           Your Message
          //         </label>
          //         <textarea
          //           id="message"
          //           name="message"
          //           value={formData.message}
          //           onChange={handleChange}
          //           required
          //           rows={5}
          //           className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-white"
          //           placeholder="How can we help you?"
          //         ></textarea>
          //       </div>
                
          //       <div>
          //         <Button  className="flex items-center">
          //           Send Message <Send className="ml-2 h-4 w-4" />
          //         </Button>
          //       </div>
          //     </form>
          //   </motion.div>
          // </div>
      //   </div>
      // </section> 

//       {/* FAQ Section */}
//       <section className="py-16 bg-gray-50 dark:bg-gray-800">
//         <div className="container mx-auto px-4 sm:px-6 lg:px-8">
//           <SectionHeading 
//             title="Frequently Asked Questions" 
//             subtitle="Find answers to common questions about our services and process."
//             centered
//           />
          
//           <div className="max-w-3xl mx-auto">
//             {[
//               {
//                 question: "What types of AI solutions do you offer?",
//                 answer: "We offer a wide range of AI solutions including custom AI model development, RAG-based knowledge assistants, AI chatbots, AI-integrated web development, and data science services. Our solutions are tailored to meet the specific needs of your business."
//               },
//               {
//                 question: "How long does it take to develop a custom AI solution?",
//                 answer: "The timeline for developing a custom AI solution varies depending on the complexity of the project. Simple projects may take a few weeks, while more complex solutions can take several months. We'll provide a detailed timeline during our initial consultation."
//               },
//               {
//                 question: "Do you offer ongoing support after project completion?",
//                 answer: "Yes, we offer ongoing support and maintenance for all our AI solutions. We can provide regular updates, performance monitoring, and technical support to ensure your solution continues to perform optimally."
//               },
//               {
//                 question: "How do you handle data privacy and security?",
//                 answer: "We take data privacy and security very seriously. We implement industry-standard security measures and comply with relevant data protection regulations. All client data is handled confidentially and securely throughout the development process."
//               },
//               {
//                 question: "What is your pricing model?",
//                 answer: "Our pricing is project-based and depends on the scope, complexity, and timeline of your specific requirements. We provide detailed quotes after an initial consultation to understand your needs. We also offer flexible engagement models including fixed-price projects and time-and-materials arrangements."
//               }
//             ].map((faq, index) => (
//               <motion.div 
//                 key={index}
//                 className="mb-6 bg-white dark:bg-gray-900 rounded-lg shadow-md overflow-hidden"
//                 initial={{ opacity: 0, y: 20 }}
//                 whileInView={{ opacity: 1, y: 0 }}
//                 transition={{ duration: 0.5, delay: index * 0.1 }}
//                 viewport={{ once: true }}
//               >
//                 <details className="group">
//                   <summary className="flex justify-between items-center p-6 cursor-pointer">
//                     <h3 className="text-lg font-medium text-gray-900 dark:text-white">
//                       {faq.question}
//                     </h3>
//                     <span className="ml-6 flex-shrink-0 text-gray-500 group-open:rotate-180 transition-transform">
//                       ▼
//                     </span>
//                   </summary>
//                   <div className="px-6 pb-6 text-gray-600 dark:text-gray-400">
//                     <p>{faq.answer}</p>
//                   </div>
//                 </details>
//               </motion.div>
//             ))}
//           </div>
//         </div>
//       </section>
//     </PageTransition>
//   );
// };

// export default Contact;






import { useState } from 'react';
import emailjs from 'emailjs-com';
import { Mail, Phone, MapPin, Send, Github, Linkedin } from 'lucide-react';
import { motion } from 'framer-motion';
import Button from '../components/Button';


export default function Example() {
  const [formData, setFormData] = useState({
    name: '',
    email:'',
    phone_no: '',
    subject: '',
    message: '',
  });
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccess(false);
    setError(false);

    const serviceID = 'service_j9x75jt';
    const templateID = 'template_vyjmn8n';
    const publicKey = 'cNKk_RTWj_vyxa7TL';

    try {
      await emailjs.send(
        serviceID,
        templateID,
        formData,
        publicKey
      );

      setSuccess(true);
      setFormData({
        name: '',
        email:'',
        phone_no: '',
        subject: '',
        message: '',
      });
    } catch (err) {
      setError(true);
      console.error('Failed to send email:', err);
    }
  };

  return (<>
  <section className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-6">
               Get in <span className="text-primary-600 dark:text-primary-400">Touch</span>
             </h1>
             <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
               Have a question or want to discuss a project? We'd love to hear from you.
             </p>
           </div>
         </div>
       </section>

         {/* Hero Section */}
         
      <div className="isolate px-6 py-15 ">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 max-w-7xl mx-auto">
        {/* Left Side - Map */}
        <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                Contact Information
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-8">
                Feel free to reach out to us with any questions or inquiries. We're here to help and would love to discuss how our AI solutions can benefit your business.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                    <Mail className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">Email</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      <a href="mailto:dipakgaddam102@gmail.com" className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
                        dipakgaddam102@gmail.com
                      </a>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                    <Phone className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">Phone</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      <a href="tel:+919725359219" className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
                        +91 9725359219
                      </a>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">Location</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      Surat, Gujarat, India
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-8">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Follow Us</h3>
                <div className="flex space-x-4">
                  <a 
                    href="https://github.com/Dipak703" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                    aria-label="GitHub"
                  >
                    <Github className="h-5 w-5" />
                  </a>
                  <a 
                    href="https://www.linkedin.com/in/dipak-gaddam?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="p-2 bg-gray-100 dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                    aria-label="LinkedIn"
                  >
                    <Linkedin className="h-5 w-5" />
                  </a>
                </div>
              </div>
            </motion.div>
        
        {/* Right Side - Contact Form */}
        <div>
          <div className="text-center">
            <h2 className="text-4xl font-semibold tracking-tight text-gray-900 sm:text-5xl">Contact Us</h2>
          </div>
          <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    // value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-white"
                    placeholder="John Doe"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Your Email
                  </label>
                 <input
                    type="email"
                    id="email"
                    name="email"
                    // value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-white"
                    placeholder="john@example.com"
                  />
                </div>

                <div>
                  <label htmlFor="number" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Your Phone No.
                  </label>
                 <input
                    type="number"
                    id="ph_no"
                    name="phone_no"
                    // value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-white"
                    placeholder="+91 97253 59219"
                  />
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Subject
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    // value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-white"
                  >
                    <option value="">Select a subject</option>
                    <option value="General Inquiry">General Inquiry</option>
                    <option value="Project Discussion">Project Discussion</option>
                    <option value="Partnership Opportunity">Partnership Opportunity</option>
                    <option value="Job Application">Job Application</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Your Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    // value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-gray-800 dark:text-white"
                    placeholder="How can we help you?"
                  ></textarea>
                </div>
                
                <div>
                  <Button  className="flex items-center">
                    Send Message <Send className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </form>
            
          </div>
          {success && <p className="mt-4 text-green-600">Email sent successfully!</p>}
          {error && <p className="mt-4 text-red-600">Failed to send the email. Please try again.</p>}
        </div>
      </div>
    
    </>
  );
}

