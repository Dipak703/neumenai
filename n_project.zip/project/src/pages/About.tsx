import React from 'react';
import { motion } from 'framer-motion';
import { Target, Lightbulb, Award, BrainCircuit, Bot, Database, Code } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import SectionHeading from '../components/SectionHeading';
import Button from '../components/Button';

const About: React.FC = () => {
  // const teamMembers = [
  //   {
  //     name: 'Dipak Gaddam',
  //     role: 'Founder & CEO',
  //     bio: 'AI researcher and entrepreneur with 10+ years of experience in machine learning and AI applications.',
  //     image: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80'
  //   },
  //   {
  //     name: 'Sarah Johnson',
  //     role: 'Chief Technology Officer',
  //     bio: 'Expert in AI model architecture with a background in computer vision and natural language processing.',
  //     image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80'
  //   },
  //   {
  //     name: 'Michael Chen',
  //     role: 'Lead Data Scientist',
  //     bio: 'Specializes in predictive modeling and developing end-to-end machine learning pipelines.',
  //     image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80'
  //   },
  //   {
  //     name: 'Elena Rodriguez',
  //     role: 'AI Solutions Architect',
  //     bio: 'Designs and implements custom AI solutions for enterprise clients across various industries.',
  //     image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80'
  //   }
  // ];

  const expertise = [
    {
      icon: <BrainCircuit className="h-8 w-8 text-primary-600" />,
      title: 'AI Model Development',
      description: 'Building custom AI models tailored to specific business needs and use cases.'
    },
    {
      icon: <Bot className="h-8 w-8 text-primary-600" />,
      title: 'RAG Models & Chatbots',
      description: 'Creating retrieval-augmented generation systems and intelligent conversational agents.'
    },
    {
      icon: <Code className="h-8 w-8 text-primary-600" />,
      title: 'AI-Powered Websites',
      description: 'Developing web applications with integrated AI capabilities for enhanced user experiences.'
    },
    {
      icon: <Database className="h-8 w-8 text-primary-600" />,
      title: 'Data Science',
      description: 'Extracting insights from data through advanced analytics and machine learning techniques.'
    }
  ];

  return (
    <PageTransition>
      {/* Hero Section */}
      <section className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              About <span className="text-primary-600 dark:text-primary-400">NeumenAI</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
              We're a team of AI specialists, data scientists, and developers passionate about 
              creating intelligent solutions that drive business growth and innovation.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                alt="AI visualization" 
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </motion.div>
            
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
                Our Mission & Vision
              </h2>
              
              <div className="space-y-8">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                  className="flex items-start space-x-4"
                >
                  <div className="flex-shrink-0 p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                    <Target className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Our Mission</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      To democratize AI technology by creating accessible, powerful, and ethical AI solutions 
                      that solve real-world problems and drive business transformation.
                    </p>
                  </div>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                  viewport={{ once: true }}
                  className="flex items-start space-x-4"
                >
                  <div className="flex-shrink-0 p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                    <Lightbulb className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Our Vision</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      To be the leading provider of innovative AI solutions that empower businesses to 
                      achieve unprecedented growth, efficiency, and competitive advantage in the digital age.
                    </p>
                  </div>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  viewport={{ once: true }}
                  className="flex items-start space-x-4"
                >
                  <div className="flex-shrink-0 p-2 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                    <Award className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Our Values</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      We believe in innovation, integrity, collaboration, and excellence in everything we do. 
                      Our commitment to ethical AI development and customer success drives our approach.
                    </p>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Expertise Section */}
      <section className="py-16 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading 
            title="Our Expertise" 
            subtitle="We specialize in cutting-edge AI technologies and methodologies to deliver exceptional results."
            centered
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {expertise.map((item, index) => (
              <motion.div
                key={index}
                className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-md text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="flex justify-center mb-4">
                  {item.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  {item.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {item.description}
                </p>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <Button to="/services">
              Explore Our Services
            </Button>
          </div>
        </div>
      </section>

      {/* Meet the Team Section
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading 
            title="Meet Our Team" 
            subtitle="Our diverse team of experts brings together years of experience in AI, machine learning, and software development."
            centered
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                className="bg-gray-50 dark:bg-gray-800 rounded-lg overflow-hidden shadow-md"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-1">
                    {member.name}
                  </h3>
                  <p className="text-primary-600 dark:text-primary-400 font-medium mb-3">
                    {member.role}
                  </p>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {member.bio}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section> */}

      {/* CTA Section */}
      <section className="py-16 bg-primary-600 dark:bg-primary-700">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to Work With Us?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            Let's discuss how our AI expertise can help your business grow and innovate.
          </p>
          <Button 
            to="/contact" 
            
          >
            Get in Touch
          </Button>
        </div>
      </section>
    </PageTransition>
  );
};

export default About;