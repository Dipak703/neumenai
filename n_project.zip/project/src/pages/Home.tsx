import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, BrainCircuit, Code, Database, BarChart3, Bot, Lightbulb, Users } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import SectionHeading from '../components/SectionHeading';
import Button from '../components/Button';

const Home: React.FC = () => {
  const services = [
    {
      icon: <BrainCircuit className="h-8 w-8 text-primary-600" />,
      title: 'AI Model Development',
      description: 'Custom AI models tailored to your specific business needs and use cases.',
    },
    {
      icon: <Bot className="h-8 w-8 text-primary-600" />,
      title: 'AI Chatbots & Agents',
      description: 'Intelligent conversational agents that enhance customer experience and automate support.',
    },
    {
      icon: <Code className="h-8 w-8 text-primary-600" />,
      title: 'AI-Integrated Web Development',
      description: 'Smart, AI-driven websites with seamless API integrations to AI backends.',
    },
    {
      icon: <Database className="h-8 w-8 text-primary-600" />,
      title: 'RAG Knowledge Assistants',
      description: 'Retrieval-augmented generation systems that leverage your business data.',
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-primary-600" />,
      title: 'Data Science & Analytics',
      description: 'Predictive modeling and data insights that drive business decisions.',
    },
    {
      icon: <Lightbulb className="h-8 w-8 text-primary-600" />,
      title: 'ML Pipeline Development',
      description: 'End-to-end machine learning pipelines for continuous model training and deployment.',
    },
  ];

  const testimonials = [
    {
      quote: "NeumenAI transformed our customer support with their custom AI chatbot. Response times decreased by 70% and customer satisfaction increased dramatically.",
      author: "Krunal Shah",
      position: "CTO, Biz-Insights."
    },
    {
      quote: "Their RAG-based knowledge assistant has revolutionized how our team accesses information. What used to take hours now takes seconds increasing our productivity.",
      author: "Pooja Vanam",
      position: "Director of Innovation, Dialumin"
      
    },
    {
      quote: "The AI-integrated web solution developed by NeumenAI increased our conversion rates by 35%. Their expertise in both AI and web development is unmatched.",
      author: "Dixit Dayani",
      position: "Marketing Director, Mindron"
      
    }
  ];

  return (
    <PageTransition>
      {/* Hero Section */}
      <section className="relative pt-24 pb-20 md:pt-32 md:pb-28 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <motion.h1 
              className="text-4xl sm:text-5xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              AI-Powered Solutions for{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-600 to-secondary-600">
                Smarter Businesses
              </span>
            </motion.h1>
            <motion.p 
              className="text-xl text-gray-600 dark:text-gray-300 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              We specialize in AI/ML model development, AI-integrated web solutions, and data science services 
              that transform how businesses operate and deliver value.
            </motion.p>
            <motion.div 
              className="flex flex-col sm:flex-row justify-center gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Button to="/contact" size="lg">
                Get a Free Consultation
              </Button>
              <Button to="/services" variant="outline" size="lg">
                Explore Our Services
              </Button>
            </motion.div>
          </div>
        </div>
        
        {/* Background decoration */}
        <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-primary-50 to-transparent dark:from-primary-900/10 dark:to-transparent -z-10"></div>
      </section>

      {/* What We Do Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading 
            title="What We Do" 
            subtitle="We leverage cutting-edge AI technologies to solve complex business problems and create innovative solutions."
            centered
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-100 dark:border-gray-700"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  {service.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {service.description}
                </p>
                <Button to="/services" variant="outline" size="sm" className="mt-2">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-6">
                Why Choose NeumenAI?
              </h2>
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-8">
                We combine deep expertise in artificial intelligence with a passion for solving 
                real-world business challenges. Our approach is collaborative, transparent, and 
                focused on delivering measurable results.
              </p>
              
              <div className="space-y-4">
                {[
                  { icon: <Users className="h-5 w-5" />, text: "Expert team with specialized knowledge in AI/ML" },
                  { icon: <Lightbulb className="h-5 w-5" />, text: "Innovative solutions tailored to your specific needs" },
                  { icon: <Database className="h-5 w-5" />, text: "Data-driven approach with measurable outcomes" },
                  { icon: <Code className="h-5 w-5" />, text: "Seamless integration with existing systems" }
                ].map((item, index) => (
                  <motion.div 
                    key={index}
                    className="flex items-start space-x-3"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <div className="flex-shrink-0 p-1 bg-primary-100 dark:bg-primary-900/30 rounded-full text-primary-600 dark:text-primary-400">
                      {item.icon}
                    </div>
                    <p className="text-gray-700 dark:text-gray-300">{item.text}</p>
                  </motion.div>
                ))}
              </div>
              
              <div className="mt-8">
                <Button to="/about">
                  Learn More About Us
                </Button>
              </div>
            </div>
            
            <motion.div
              className="relative"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <div className="aspect-w-4 aspect-h-3 rounded-xl overflow-hidden shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80" 
                  alt="AI visualization" 
                  className="object-cover w-full h-full"
                />
              </div>
              
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading 
            title="What Our Clients Say" 
            subtitle="Don't just take our word for it. Here's what our clients have to say about working with us."
            centered
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-md border border-gray-100 dark:border-gray-700"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="mb-4">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-yellow-400">★</span>
                  ))}
                </div>
                <p className="text-gray-700 dark:text-gray-300 mb-6 italic">
                  "{testimonial.quote}"
                </p>
                <div className="flex items-center">
                  {/* <div className="flex-shrink-0 mr-4">
                    <img 
                      src={testimonial.image} 
                      alt={testimonial.author} 
                      className="w-12 h-12 rounded-full object-cover"
                    />
                  </div> */}
                  <div>
                    <h4 className="text-base font-semibold text-gray-900 dark:text-white">
                      {testimonial.author}
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {testimonial.position}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary-600 to-secondary-700 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your Business with AI?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
            Get in touch today for a free consultation and discover how our AI solutions can drive growth and innovation for your business.
          </p>
          <Button 
            to="/contact" 
            
            size="lg"
          >
            Get Started Today
          </Button>
        </div>
      </section>
    </PageTransition>
  );
};

export default Home;