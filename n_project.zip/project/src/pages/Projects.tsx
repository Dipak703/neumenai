import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import PageTransition from '../components/PageTransition';
// import SectionHeading from '../components/SectionHeading';
import Button from '../components/Button';

const Projects: React.FC = () => {
  const projects = [{
      title: "RAG Model for AI Chatbots",
      
      problem: "TechSupport Pro needed to improve their customer support efficiency while maintaining high-quality responses for technical queries.",
      solution: "We implemented a Retrieval-Augmented Generation (RAG) system using LangChain and ChromaDB that leverages their knowledge base to provide accurate, contextual responses to customer inquiries.",
      technologies: ["LangChain", "ChromaDB", "Llama2", "RAG", "Vector Embeddings"],
      results: [
        "73% reduction in response time",
        "91% customer satisfaction rate (up from 76%)",
        "42% decrease in escalated tickets"
      ],
      image: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
    },
    {
      "title": "Augmented Reality Jewelry Try-On",
      "problem": "Shimmer Trends wanted to enhance the online shopping experience by enabling customers to virtually try on jewelry, overcoming the challenge of imagining how products would look when worn.",
      "solution": "We developed an augmented reality application that uses advanced face and hand tracking to allow users to try on rings, necklaces, earrings, and bracelets in real-time. The app accurately maps jewelry onto the user’s features, adapting to movements and lighting conditions for a realistic experience.",
      "technologies": ["Unity", "ARKit", "ARCore", "3D Modeling", "Real-Time Tracking"],
      "results": [
        "30% increase in customer engagement",
        "20% boost in online jewelry sales",
        "Enhanced customer satisfaction with a 4.8/5 average app rating"
      ],
      "image": "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
    },
    
    {
      title: "Jewelry Feature Extraction & AI Description Generation",
      
      problem: "LuxuryGems needed to automate the creation of detailed product descriptions for thousands of jewelry items to improve SEO and customer engagement.",
      solution: "We built an AI system that analyzes product images to identify key features (gemstone type, cut, setting style) and generates accurate, SEO-optimized product descriptions.",
      technologies: ["Computer Vision", "NLP", "GPT-4", "Feature Extraction"],
      results: [
        "Generated descriptions for 10,000+ products in 48 hours",
        "35% increase in organic search traffic",
        "28% improvement in conversion rates"
      ],
      image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
    },
    
    
      {
        title: "Agentic AI: Autonomous Decision-Making Platform",
        problem: "Organizations struggled with optimizing complex workflows and making real-time decisions due to the limitations of traditional rule-based systems and human intervention.",
        solution: "We developed Agentic AI, a platform powered by advanced reinforcement learning and multi-agent systems that enables autonomous decision-making in dynamic environments. The platform is designed to adapt to real-time data, learn from outcomes, and provide optimal solutions for intricate problems such as supply chain logistics, financial portfolio management, and customer service optimization.",
        technologies: ["Reinforcement Learning", "Multi-Agent Systems", "Python", "TensorFlow", "AWS"],
        results: [
          "50% improvement in workflow efficiency",
          "35% reduction in operational costs",
          "Adaptive decision-making with an 85% success rate in dynamic scenarios"
        ],
        image: "public/AgenticAI.webp"
      
    }
  ];

  return (
    <PageTransition>
      {/* Hero Section */}
      <section className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Our <span className="text-primary-600 dark:text-primary-400">Projects</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
              Explore our case studies showcasing how we've helped businesses solve complex 
              challenges with innovative AI solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-24">
            {projects.map((project, index) => (
              <motion.div 
                key={index}
                className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
              >
                <div className={`${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                 
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                    {project.title}
                  </h2>
                 
                  
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                        The Challenge
                      </h3>
                      <p className="text-gray-600 dark:text-gray-400">
                        {project.problem}
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                        Our Solution
                      </h3>
                      <p className="text-gray-600 dark:text-gray-400 mb-4">
                        {project.solution}
                      </p>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        {project.technologies.map((tech, techIndex) => (
                          <span 
                            key={techIndex}
                            className="px-3 py-1 bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 rounded-full text-sm font-medium"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                        Results
                      </h3>
                      <ul className="space-y-2">
                        {project.results.map((result, resultIndex) => (
                          <li key={resultIndex} className="flex items-start space-x-2 text-gray-600 dark:text-gray-400">
                            <span className="text-primary-600 dark:text-primary-400">•</span>
                            <span>{result}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div className={`${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                  <div className="rounded-lg overflow-hidden shadow-lg">
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-auto"
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
              Ready to Start Your Own Success Story?
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
              Let's discuss how our AI expertise can help solve your business challenges and drive growth.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button to="/contact" size="lg">
                Get in Touch
              </Button>
              <Button to="/services" variant="outline" size="lg">
                Explore Our Services <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

export default Projects;